<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/admin_item/_itemform.html.twig */
class __TwigTemplate_a8f3c4c75028c5b6827b5ad8873ec1cc084d3ec9e5d0ff3d4b3099e968a9af2b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/admin_item/_itemform.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/admin_item/_itemform.html.twig"));

        // line 1
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 1, $this->source); })()), 'form_start');
        echo "

<div class=\"field\">
  <div class=\"label\">";
        // line 4
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 4, $this->source); })()), "title", [], "any", false, false, false, 4), 'label', ["label" => "title"]);
        echo "</div>
  <div class=\"control\">
    ";
        // line 6
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 6, $this->source); })()), "title", [], "any", false, false, false, 6), 'widget', ["attr" => ["class" => "input"]]);
        echo "
  </div>
</div>

<div class=\"field\">
  <div class=\"label\">";
        // line 11
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 11, $this->source); })()), "subtitle", [], "any", false, false, false, 11), 'label', ["label" => "subtitle"]);
        echo "</div>
  <div class=\"control\">
    ";
        // line 13
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 13, $this->source); })()), "subtitle", [], "any", false, false, false, 13), 'widget', ["attr" => ["class" => "input"]]);
        echo "
  </div>
</div>

<div class=\"field\">
  <div class=\"label\">";
        // line 18
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 18, $this->source); })()), "period", [], "any", false, false, false, 18), 'label', ["label" => "period"]);
        echo "</div>
  <div class=\"control\">
    ";
        // line 20
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 20, $this->source); })()), "period", [], "any", false, false, false, 20), 'widget', ["attr" => ["class" => "input"]]);
        echo "
  </div>
</div>

<div class=\"field\">
  <div class=\"label\">";
        // line 25
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 25, $this->source); })()), "description", [], "any", false, false, false, 25), 'label', ["label" => "description"]);
        echo "</div>
  <div class=\"control\">
    ";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 27, $this->source); })()), "description", [], "any", false, false, false, 27), 'widget', ["attr" => ["class" => "textarea", "rows" => "5"]]);
        echo "
  </div>
</div>

<div class=\"columns\">
  <div class=\"column\">
    <div class=\"field\">
      <div class=\"label\">";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 34, $this->source); })()), "category", [], "any", false, false, false, 34), 'label', ["label" => "categories"]);
        echo "</div>
      <div class=\"control\">
        <div class='select'> ";
        // line 36
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 36, $this->source); })()), "category", [], "any", false, false, false, 36), 'widget');
        echo " </div>
      </div>
    </div>
  </div>
  <div class=\"column\">
    <div class=\"field\">
      <div class=\"label\">";
        // line 42
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 42, $this->source); })()), "position", [], "any", false, false, false, 42), 'label', ["label" => "position"]);
        echo "</div>
      <div class=\"control\">
        ";
        // line 44
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 44, $this->source); })()), "position", [], "any", false, false, false, 44), 'widget', ["attr" => ["class" => "input"]]);
        echo "
      </div>
    </div>

  </div>
</div>

<div class=\"field is-grouped\">
  <div class=\"control\">
    <button class=\"button is-link is-light\">";
        // line 53
        echo twig_escape_filter($this->env, (((isset($context["button"]) || array_key_exists("button", $context))) ? (_twig_default_filter((isset($context["button"]) || array_key_exists("button", $context) ? $context["button"] : (function () { throw new RuntimeError('Variable "button" does not exist.', 53, $this->source); })()), "Sauvegarder")) : ("Sauvegarder")), "html", null, true);
        echo "</button>
  </div>
  <div class=\"control\">
    <a href=\"";
        // line 56
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_item");
        echo "\" class=\"button is-light\">Annuler</a>
  </div>

</div>
";
        // line 60
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 60, $this->source); })()), 'form_end');
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "admin/admin_item/_itemform.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 60,  140 => 56,  134 => 53,  122 => 44,  117 => 42,  108 => 36,  103 => 34,  93 => 27,  88 => 25,  80 => 20,  75 => 18,  67 => 13,  62 => 11,  54 => 6,  49 => 4,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ form_start(form) }}

<div class=\"field\">
  <div class=\"label\">{{ form_label(form.title, 'title') }}</div>
  <div class=\"control\">
    {{ form_widget(form.title, {'attr': {'class': 'input'}}) }}
  </div>
</div>

<div class=\"field\">
  <div class=\"label\">{{ form_label(form.subtitle, 'subtitle') }}</div>
  <div class=\"control\">
    {{ form_widget(form.subtitle, {'attr': {'class': 'input'}}) }}
  </div>
</div>

<div class=\"field\">
  <div class=\"label\">{{ form_label(form.period, 'period') }}</div>
  <div class=\"control\">
    {{ form_widget(form.period, {'attr': {'class': 'input'}}) }}
  </div>
</div>

<div class=\"field\">
  <div class=\"label\">{{ form_label(form.description, 'description') }}</div>
  <div class=\"control\">
    {{ form_widget(form.description, {'attr': {'class': 'textarea', 'rows': '5'}}) }}
  </div>
</div>

<div class=\"columns\">
  <div class=\"column\">
    <div class=\"field\">
      <div class=\"label\">{{ form_label(form.category, 'categories') }}</div>
      <div class=\"control\">
        <div class='select'> {{ form_widget(form.category) }} </div>
      </div>
    </div>
  </div>
  <div class=\"column\">
    <div class=\"field\">
      <div class=\"label\">{{ form_label(form.position, 'position') }}</div>
      <div class=\"control\">
        {{ form_widget(form.position, {'attr': {'class': 'input'}}) }}
      </div>
    </div>

  </div>
</div>

<div class=\"field is-grouped\">
  <div class=\"control\">
    <button class=\"button is-link is-light\">{{ button|default('Sauvegarder')}}</button>
  </div>
  <div class=\"control\">
    <a href=\"{{path('admin_item')}}\" class=\"button is-light\">Annuler</a>
  </div>

</div>
{{ form_end(form) }}", "admin/admin_item/_itemform.html.twig", "C:\\wamp64\\www\\mcwebsite\\templates\\admin\\admin_item\\_itemform.html.twig");
    }
}
