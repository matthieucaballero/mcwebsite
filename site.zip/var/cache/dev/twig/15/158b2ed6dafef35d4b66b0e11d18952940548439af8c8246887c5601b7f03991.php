<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/admin_item/index.html.twig */
class __TwigTemplate_767b0b693f1111603dc6d5f43ecd6de3dd9b91cfa09e6885039ca2e1e31a20a3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'admin' => [$this, 'block_admin'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "admin/index.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/admin_item/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/admin_item/index.html.twig"));

        $this->parent = $this->loadTemplate("admin/index.html.twig", "admin/admin_item/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_admin($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "admin"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "admin"));

        // line 4
        echo "
<section class=\"container is-fluid\">

    <div class=\"columns is-centered\" style=\"padding: 2em 0;\">
        <a href=\"";
        // line 8
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin.item.new");
        echo " \" class=\"button is-fullwidth\">Créer</a>
    </div>

    <div class=\"columns is-centered\" style=\"padding: 2em 0;\">
        <div class=\"column is-full\">
            <table class=\"table is-fullwidth\">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Position</th>
                        <th>Catégorie</th>
                        <th>Titre</th>
                        <th>Sous-titre</th>
                        <th>Période</th>
                        <th>Description</th>
                        <th>Actions</th>
                        
                    </tr>
                </thead>
                <tbody>
                    ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new RuntimeError('Variable "items" does not exist.', 28, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 29
            echo "                    <tr>
                        <td>";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 30), "html", null, true);
            echo " </td>
                        <td>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "position", [], "any", false, false, false, 31), "html", null, true);
            echo " </td>
                        <td>";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "category", [], "any", false, false, false, 32), "name", [], "any", false, false, false, 32), "html", null, true);
            echo " </td>
                        <td>";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 33), "html", null, true);
            echo " </td>
                        <td>";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "subtitle", [], "any", false, false, false, 34), "html", null, true);
            echo " </td>
                        <td>";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "period", [], "any", false, false, false, 35), "html", null, true);
            echo " </td>
                        <td>";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, false, 36), "html", null, true);
            echo " </td>
                        <td>
                            <div class=\"buttons\">
                                <a href=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin.item.edit", ["id" => twig_get_attribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 39)]), "html", null, true);
            echo "\" class=\"button \">Editer</a>
                                <form method='POST' action=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin.item.delete", ["id" => twig_get_attribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 40)]), "html", null, true);
            echo "\">
                                    <input type=\"hidden\" name=\"_method\" value=\"DELETE\">
                                    <input type=\"hidden\" name=\"_token\" value='";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken(("delete" . twig_get_attribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 42))), "html", null, true);
            echo "'>
                                    <button onclick=\"return confirm('Etes vous sur?');\" class='button is-danger is-light'>Supprimer</button>
                                </form>                    
                            </div>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "                </tbody>

            </table>
        </div>
    </div>

</section>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "admin/admin_item/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 49,  143 => 42,  138 => 40,  134 => 39,  128 => 36,  124 => 35,  120 => 34,  116 => 33,  112 => 32,  108 => 31,  104 => 30,  101 => 29,  97 => 28,  74 => 8,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'admin/index.html.twig' %}

{% block admin %}

<section class=\"container is-fluid\">

    <div class=\"columns is-centered\" style=\"padding: 2em 0;\">
        <a href=\"{{path('admin.item.new')}} \" class=\"button is-fullwidth\">Créer</a>
    </div>

    <div class=\"columns is-centered\" style=\"padding: 2em 0;\">
        <div class=\"column is-full\">
            <table class=\"table is-fullwidth\">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Position</th>
                        <th>Catégorie</th>
                        <th>Titre</th>
                        <th>Sous-titre</th>
                        <th>Période</th>
                        <th>Description</th>
                        <th>Actions</th>
                        
                    </tr>
                </thead>
                <tbody>
                    {% for item in items %}
                    <tr>
                        <td>{{item.id}} </td>
                        <td>{{item.position}} </td>
                        <td>{{item.category.name}} </td>
                        <td>{{item.title}} </td>
                        <td>{{item.subtitle}} </td>
                        <td>{{item.period}} </td>
                        <td>{{item.description}} </td>
                        <td>
                            <div class=\"buttons\">
                                <a href=\"{{path('admin.item.edit', {id: item.id})}}\" class=\"button \">Editer</a>
                                <form method='POST' action=\"{{path('admin.item.delete', {id: item.id})}}\">
                                    <input type=\"hidden\" name=\"_method\" value=\"DELETE\">
                                    <input type=\"hidden\" name=\"_token\" value='{{ csrf_token('delete' ~ item.id) }}'>
                                    <button onclick=\"return confirm('Etes vous sur?');\" class='button is-danger is-light'>Supprimer</button>
                                </form>                    
                            </div>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>

            </table>
        </div>
    </div>

</section>
{% endblock %}", "admin/admin_item/index.html.twig", "C:\\wamp64\\www\\mcwebsite\\templates\\admin\\admin_item\\index.html.twig");
    }
}
