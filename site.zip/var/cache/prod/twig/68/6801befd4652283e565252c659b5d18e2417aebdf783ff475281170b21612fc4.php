<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/admin_item/_itemform.html.twig */
class __TwigTemplate_d13597cbe5bc0596c4317cd52347116fbc646e992e8b20c779c4f00bc997392d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        echo "

<div class=\"field\">
  <div class=\"label\">";
        // line 4
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 4), 'label', ["label" => "title"]);
        echo "</div>
  <div class=\"control\">
    ";
        // line 6
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 6), 'widget', ["attr" => ["class" => "input"]]);
        echo "
  </div>
</div>

<div class=\"field\">
  <div class=\"label\">";
        // line 11
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "subtitle", [], "any", false, false, false, 11), 'label', ["label" => "subtitle"]);
        echo "</div>
  <div class=\"control\">
    ";
        // line 13
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "subtitle", [], "any", false, false, false, 13), 'widget', ["attr" => ["class" => "input"]]);
        echo "
  </div>
</div>

<div class=\"field\">
  <div class=\"label\">";
        // line 18
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "period", [], "any", false, false, false, 18), 'label', ["label" => "period"]);
        echo "</div>
  <div class=\"control\">
    ";
        // line 20
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "period", [], "any", false, false, false, 20), 'widget', ["attr" => ["class" => "input"]]);
        echo "
  </div>
</div>

<div class=\"field\">
  <div class=\"label\">";
        // line 25
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "description", [], "any", false, false, false, 25), 'label', ["label" => "description"]);
        echo "</div>
  <div class=\"control\">
    ";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "description", [], "any", false, false, false, 27), 'widget', ["attr" => ["class" => "textarea", "rows" => "5"]]);
        echo "
  </div>
</div>

<div class=\"columns\">
  <div class=\"column\">
    <div class=\"field\">
      <div class=\"label\">";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "category", [], "any", false, false, false, 34), 'label', ["label" => "categories"]);
        echo "</div>
      <div class=\"control\">
        <div class='select'> ";
        // line 36
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "category", [], "any", false, false, false, 36), 'widget');
        echo " </div>
      </div>
    </div>
  </div>
  <div class=\"column\">
    <div class=\"field\">
      <div class=\"label\">";
        // line 42
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "position", [], "any", false, false, false, 42), 'label', ["label" => "position"]);
        echo "</div>
      <div class=\"control\">
        ";
        // line 44
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "position", [], "any", false, false, false, 44), 'widget', ["attr" => ["class" => "input"]]);
        echo "
      </div>
    </div>

  </div>
</div>

<div class=\"field is-grouped\">
  <div class=\"control\">
    <button class=\"button is-link is-light\">";
        // line 53
        echo twig_escape_filter($this->env, (((isset($context["button"]) || array_key_exists("button", $context))) ? (_twig_default_filter(($context["button"] ?? null), "Sauvegarder")) : ("Sauvegarder")), "html", null, true);
        echo "</button>
  </div>
  <div class=\"control\">
    <a href=\"";
        // line 56
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_item");
        echo "\" class=\"button is-light\">Annuler</a>
  </div>

</div>
";
        // line 60
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
    }

    public function getTemplateName()
    {
        return "admin/admin_item/_itemform.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  141 => 60,  134 => 56,  128 => 53,  116 => 44,  111 => 42,  102 => 36,  97 => 34,  87 => 27,  82 => 25,  74 => 20,  69 => 18,  61 => 13,  56 => 11,  48 => 6,  43 => 4,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "admin/admin_item/_itemform.html.twig", "C:\\wamp64\\www\\mcwebsite\\templates\\admin\\admin_item\\_itemform.html.twig");
    }
}
