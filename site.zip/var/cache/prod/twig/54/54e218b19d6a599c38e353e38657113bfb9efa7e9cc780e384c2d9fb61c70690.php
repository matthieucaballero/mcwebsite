<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/admin_category/associatedItems.html.twig */
class __TwigTemplate_7684a01b6207d376cb49f06b02c358490ebe0f06c1fd31b3c1a14154af199d62 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'admin' => [$this, 'block_admin'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "admin/index.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("admin/index.html.twig", "admin/admin_category/associatedItems.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_admin($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "
<section class=\"container is-fluid\">

    <h2 class=\"title has-text-centered\" style=\"margin: 1em;\">";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["category"] ?? null), "name", [], "any", false, false, false, 7), "html", null, true);
        echo "</h2>

    ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["items"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 10
            echo "    <div class=\"card\" style=\"margin: 1em;\">
        <header class=\"card-header\">
          <p class=\"card-header-title\">
            ";
            // line 13
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 13), "html", null, true);
            echo "
          </p>
        </header>
        <div class=\"card-content\">
          <div class=\"content\">
            <h5>";
            // line 18
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "subtitle", [], "any", false, false, false, 18), "html", null, true);
            echo "</h5>
            <h6>Description</h5>
            <p>";
            // line 20
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, false, 20), "html", null, true);
            echo "</p>
            <h6>Periode</h6>
            <p>";
            // line 22
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "period", [], "any", false, false, false, 22), "html", null, true);
            echo "</p>
          </div>
        </div>
        <footer class=\"card-footer\" style=\"padding: 0.5em;\">
            <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin.item.edit", ["id" => twig_get_attribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 26)]), "html", null, true);
            echo "\" class=\"button \">Editer</a>
        </footer>
      </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "
</section>


";
    }

    public function getTemplateName()
    {
        return "admin/admin_category/associatedItems.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 30,  94 => 26,  87 => 22,  82 => 20,  77 => 18,  69 => 13,  64 => 10,  60 => 9,  55 => 7,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "admin/admin_category/associatedItems.html.twig", "C:\\wamp64\\www\\mcwebsite\\templates\\admin\\admin_category\\associatedItems.html.twig");
    }
}
