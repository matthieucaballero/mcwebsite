<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/admin_item/edit.html.twig */
class __TwigTemplate_622e9eb4e849bbf42843801896909d58cff21979deb6e881eb337f6227515047 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'admin' => [$this, 'block_admin'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "admin/index.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("admin/index.html.twig", "admin/admin_item/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_admin($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "
<section class=\"section\">
    <h1 class=\"title\">Editer un item</h1>
    ";
        // line 7
        $this->loadTemplate("admin/admin_item/_itemform.html.twig", "admin/admin_item/edit.html.twig", 7)->display(twig_array_merge($context, ["button" => "Editer"]));
        // line 8
        echo "
</section>

";
    }

    public function getTemplateName()
    {
        return "admin/admin_item/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  55 => 7,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "admin/admin_item/edit.html.twig", "C:\\wamp64\\www\\mcwebsite\\templates\\admin\\admin_item\\edit.html.twig");
    }
}
