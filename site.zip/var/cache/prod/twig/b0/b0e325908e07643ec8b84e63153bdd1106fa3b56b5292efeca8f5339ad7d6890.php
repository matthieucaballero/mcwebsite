<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/index.html.twig */
class __TwigTemplate_7355e409b5424fe4ac70bff2cc0ff652bc5dcef92564bad93d531d922d8fec3a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'body' => [$this, 'block_body'],
            'admin' => [$this, 'block_admin'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "admin/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 5
        echo "<nav class=\"navbar\" role=\"navigation\" aria-label=\"main navigation\">
  <div class=\"navbar-brand\">
    <a class=\"navbar-item\" href=\"";
        // line 7
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin");
        echo " \">
      MC - Administration
    </a>

    <a role=\"button\" class=\"navbar-burger burger\" aria-label=\"menu\" aria-expanded=\"false\"
      data-target=\"navbarBasicExample\">
      <span aria-hidden=\"true\"></span>
      <span aria-hidden=\"true\"></span>
      <span aria-hidden=\"true\"></span>
    </a>
  </div>

  <div class=\"navbar-menu\">
    <div class=\"navbar-start\">
      <a class=\"navbar-item\" href=\"";
        // line 21
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_category");
        echo " \">
        Catégories
      </a>

      <a class=\"navbar-item\" href=\"";
        // line 25
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_item");
        echo " \">
        Items
      </a>


    </div>

    <div class=\"navbar-end\">
      <div class=\"navbar-item\">
        ";
        // line 34
        if (twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 34)) {
            // line 35
            echo "        <div class=\"buttons\">
          <a href=\"";
            // line 36
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
            echo " \" class=\"button is-light\">Log out</a>
        </div>
        ";
        }
        // line 39
        echo "      </div>
    </div>

  </div>
</nav>

";
    }

    // line 47
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 48
        echo "
<section id=\"adminContainer\">

  ";
        // line 51
        $this->displayBlock('admin', $context, $blocks);
        // line 54
        echo "  
</section>

";
    }

    // line 51
    public function block_admin($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 52
        echo "  <p style=\"padding: 1rem;\">Ici l'accueil de la section d'administration</p>
  ";
    }

    public function getTemplateName()
    {
        return "admin/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 52,  131 => 51,  124 => 54,  122 => 51,  117 => 48,  113 => 47,  103 => 39,  97 => 36,  94 => 35,  92 => 34,  80 => 25,  73 => 21,  56 => 7,  52 => 5,  48 => 4,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "admin/index.html.twig", "C:\\wamp64\\www\\mcwebsite\\templates\\admin\\index.html.twig");
    }
}
