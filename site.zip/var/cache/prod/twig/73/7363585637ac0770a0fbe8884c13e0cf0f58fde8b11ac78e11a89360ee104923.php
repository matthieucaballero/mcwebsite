<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_4d586bfe0d84a960affde2a0d98386bafe2ba6421cc489998b7bb8c51ca2f9a5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'header' => [$this, 'block_header'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <meta name=\"Description\" content=\"\">

        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,maximum-scale=5.0,user-scalable=yes\">

        <title>Matthieu Caballero - Développeur web";
        // line 9
        $this->displayBlock('title', $context, $blocks);
        echo "</title>



        ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 17
        echo "    </head>
    <body>

        ";
        // line 20
        $this->displayBlock('header', $context, $blocks);
        // line 21
        echo "        ";
        $this->displayBlock('body', $context, $blocks);
        // line 22
        echo "

        <footer class=\"p1 has-background-white\">
            <div class=\"content has-text-centered\">
              <p class=\"mv0\">
                <strong>Matthieu Caballero</strong> - Développeur web
              </p>
              <p class=\"is-size-7 mv0\">Réalisé avec les frameworks Symfony 5 et Bulma.</p>
            </div>
          </footer>
        <script src=\"https://kit.fontawesome.com/2a0888dafb.js\" crossorigin=\"anonymous\"></script>
        ";
        // line 33
        $this->displayBlock('javascripts', $context, $blocks);
        // line 34
        echo "    </body>
</html>
";
    }

    // line 9
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 13
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 14
        echo "          <link rel=\"stylesheet\" href=\"/bulma.css\">
          <link rel=\"stylesheet\" href=\"/style.css\">
        ";
    }

    // line 20
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 21
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 33
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  120 => 33,  114 => 21,  108 => 20,  102 => 14,  98 => 13,  92 => 9,  86 => 34,  84 => 33,  71 => 22,  68 => 21,  66 => 20,  61 => 17,  59 => 13,  52 => 9,  42 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "base.html.twig", "C:\\wamp64\\www\\mcwebsite\\templates\\base.html.twig");
    }
}
