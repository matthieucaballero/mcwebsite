<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/index.html.twig */
class __TwigTemplate_6adff2576a0cd362ac319306d847e2206296cf4ebe9aed946da25093475793ff extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "home/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "

<nav id=\"chapeau\" class=\"level p2 has-background-white\">
    <div class=\"level-left\">
        <div class=\"level-item has-text-centered mv1\">
            <figure class=\"image is-128x128\">
                <img class=\"is-rounded\" src=\"img/portrait.jpg\">
            </figure>
        </div>
        <div class=\"level-item has-text-centered\">
            <div>
                <p class=\"title is-4\">Matthieu Caballero</p>
            </div>
        </div>
    </div>

    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["items"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 23
            echo "    ";
            if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "category", [], "any", false, false, false, 23), "name", [], "any", false, false, false, 23), "Général") && (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 23), "Téléphone") || 0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 23), "E-mail")))) {
                // line 24
                echo "    <div class=\"level-item has-text-centered is-hidden-mobile\">
        <div>
            <p class=\"heading\">";
                // line 26
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 26), "html", null, true);
                echo " </p>
            <p class=\"subtitle is-6\">";
                // line 27
                echo nl2br(twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, false, 27), "html", null, true));
                echo " </p>
        </div>
    </div>
    ";
            }
            // line 31
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "
    <div class=\"level-right\">
        <div class=\"level-item has-text-centered mv1\">

            <a href=\"https://www.linkedin.com/in/matthieu-caballero/\" title=\"Allez vers profil linkedin\"><i class=\"fab fa-linkedin-in\"></i></a>

            ";
        // line 38
        if (twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 38)) {
            // line 39
            echo "            <div class=\"buttons\">
                <a href=\"";
            // line 40
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
            echo " \" class=\"button is-light\">Log out</a>
            </div>
            ";
        }
        // line 43
        echo "        </div>
    </div>
</nav>


<section id=\"sectionIndex\" class=\"container p2 \">

    ";
        // line 50
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["categories"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 51
            echo "    <article class=\"columns has-text-white-ter\">
        <div class=\"column has-text-right has-text-centered-mobile\">
            <h3 class=\"title is-4 has-text-white-ter\">";
            // line 53
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["category"], "name", [], "any", false, false, false, 53), "html", null, true);
            echo "</h3>
        </div>
        <div class=\"column is-three-quarters has-text-centered-mobile\">
            ";
            // line 56
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["items"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 57
                echo "                ";
                if (0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "category", [], "any", false, false, false, 57), "id", [], "any", false, false, false, 57), twig_get_attribute($this->env, $this->source, $context["category"], "id", [], "any", false, false, false, 57))) {
                    // line 58
                    echo "                <div class=\"mb2\">
                    <h4 class=\"is-size-5\">";
                    // line 59
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 59), "html", null, true);
                    echo "</h4>
                    <h5 class=\"is-size-6\">";
                    // line 60
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "subtitle", [], "any", false, false, false, 60), "html", null, true);
                    echo "</h5>
                    <h6 class=\"is-size-7\">";
                    // line 61
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "period", [], "any", false, false, false, 61), "html", null, true);
                    echo "</h6>
                    <p>";
                    // line 62
                    echo nl2br(twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, false, 62), "html", null, true));
                    echo "</p>
                </div>
                ";
                }
                // line 65
                echo "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 66
            echo "        </div>
    </article>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo "
</section>

";
    }

    public function getTemplateName()
    {
        return "home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  180 => 69,  172 => 66,  166 => 65,  160 => 62,  156 => 61,  152 => 60,  148 => 59,  145 => 58,  142 => 57,  138 => 56,  132 => 53,  128 => 51,  124 => 50,  115 => 43,  109 => 40,  106 => 39,  104 => 38,  96 => 32,  90 => 31,  83 => 27,  79 => 26,  75 => 24,  72 => 23,  68 => 22,  50 => 6,  46 => 5,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "home/index.html.twig", "C:\\wamp64\\www\\mcwebsite\\templates\\home\\index.html.twig");
    }
}
