<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/admin_category/edit.html.twig */
class __TwigTemplate_3cc6bfaf03ddd1f1906304928c6bff28c8ee56d34e92a46d3a9968f9c1ea35b7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'admin' => [$this, 'block_admin'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "admin/index.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("admin/index.html.twig", "admin/admin_category/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_admin($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "
<section class=\"section\">
    <h1 class=\"title\">Editer une catégorie</h1>
    ";
        // line 7
        $this->loadTemplate("admin/admin_category/_categoryform.html.twig", "admin/admin_category/edit.html.twig", 7)->display(twig_array_merge($context, ["button" => "Editer"]));
        // line 8
        echo "
</section>

";
    }

    public function getTemplateName()
    {
        return "admin/admin_category/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  55 => 7,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "admin/admin_category/edit.html.twig", "C:\\wamp64\\www\\mcwebsite\\templates\\admin\\admin_category\\edit.html.twig");
    }
}
