<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* security/login.html.twig */
class __TwigTemplate_f3f5d7b1872665d82c963d0dee6ae1f2a15ffa66f5ce92ffa67e365a714b2824 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Se connecter";
    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "
<section class=\"container\">

    ";
        // line 9
        if (($context["error"] ?? null)) {
            // line 10
            echo "    <article class=\"message is-danger\">
        <div class=\"message-body\">
            ";
            // line 12
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, ($context["error"] ?? null), "messageKey", [], "any", false, false, false, 12), twig_get_attribute($this->env, $this->source, ($context["error"] ?? null), "messagedata", [], "any", false, false, false, 12), "security"), "html", null, true);
            echo "
        </div>
    </article>
    ";
        }
        // line 16
        echo "
    <form action=\"";
        // line 17
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        echo "\" method=\"POST\" style=\"padding: 2em;\">

        <div class=\"field\">
            <label class=\"label has-text-white\" for=\"username\">Nom d'utilisateur</label>
            <div class=\"control\">
                <input type=\"text\" name=\"_username\" id=\"username\" class=\"input\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, ($context["last_username"] ?? null), "html", null, true);
        echo " \">
            </div>
        </div>

        <div class=\"field\">
            <label class=\"label has-text-white\" for=\"password\">Mot de passe</label>
            <div class=\"control\">
                <input type=\"password\" name=\"_password\" id=\"password\" class=\"input\">
            </div>
        </div>
        <div class=\"control\">
            <button type=\"submit\" class=\"button is-link\">Se connecter</button>
        </div>
    </form>
</section>

";
    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 22,  79 => 17,  76 => 16,  69 => 12,  65 => 10,  63 => 9,  58 => 6,  54 => 5,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "security/login.html.twig", "C:\\wamp64\\www\\mcwebsite\\templates\\security\\login.html.twig");
    }
}
