<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/admin/category' => [[['_route' => 'admin_category', '_controller' => 'App\\Controller\\Admin\\AdminCategoryController::index'], null, null, null, false, false, null]],
        '/admin/category/create' => [[['_route' => 'admin.category.new', '_controller' => 'App\\Controller\\Admin\\AdminCategoryController::new'], null, null, null, false, false, null]],
        '/admin' => [[['_route' => 'admin', '_controller' => 'App\\Controller\\Admin\\AdminController::index'], null, null, null, false, false, null]],
        '/admin/item' => [[['_route' => 'admin_item', '_controller' => 'App\\Controller\\Admin\\AdminItemController::index'], null, null, null, false, false, null]],
        '/admin/item/create' => [[['_route' => 'admin.item.new', '_controller' => 'App\\Controller\\Admin\\AdminItemController::new'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'home', '_controller' => 'App\\Controller\\HomeController::index'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/admin/(?'
                    .'|category/([^/]++)(?'
                        .'|(*:37)'
                        .'|/items(*:50)'
                        .'|(*:57)'
                    .')'
                    .'|item/([^/]++)(?'
                        .'|(*:81)'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        37 => [[['_route' => 'admin.category.edit', '_controller' => 'App\\Controller\\Admin\\AdminCategoryController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        50 => [[['_route' => 'admin.category.items', '_controller' => 'App\\Controller\\Admin\\AdminCategoryController::associatedItems'], ['id'], ['GET' => 0], null, false, false, null]],
        57 => [[['_route' => 'admin.category.delete', '_controller' => 'App\\Controller\\Admin\\AdminCategoryController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        81 => [
            [['_route' => 'admin.item.edit', '_controller' => 'App\\Controller\\Admin\\AdminItemController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [['_route' => 'admin.item.delete', '_controller' => 'App\\Controller\\Admin\\AdminItemController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
